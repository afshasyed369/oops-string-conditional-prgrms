import java.util.Scanner;
class Main {
	public static void main(String[] args) {
		Double number , sum = 0.0;
		// create an object of Scanner
		Scanner input = new Scanner(System.in);
		
		for(int i=1;i<6;++i) {
			System.out.print("Enter number " + i + " :");
			//takes double type input from the user
			number = input.nextDouble();
			//if number is negative, the iteration is skipped
			if (number <= 0.0) {
				continue;
			}
			sum += number;
		}
		System.out.println("Sum = " + sum);
		input.close();
	}
}
