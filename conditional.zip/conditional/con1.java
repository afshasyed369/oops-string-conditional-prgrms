class IFStatement {
	public static void main(String[] args) {
		int number =10;
		
		//checks if number is greater than 0
		if(number > 0) {
			System.out.println("The number is positive.");
		}
		System.out.println("This statement is always executed.");
		
	}
}
