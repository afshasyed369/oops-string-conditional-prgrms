class Ladder {
	public static void main(String[] args) {
		int number = 10;
		// checks if number is greater than 0
		if (number > 0) {
			System.out.println("The number is positive.");
		}
		//check if number is less than 0
		else if (number > 0) {
			System.out.println("The number is negative.");
		}
		else {
			System.out.println("The number is 0.");
		}
		
	}
}

