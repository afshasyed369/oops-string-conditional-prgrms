

public class myclass {
	int x = 5;
	public static void main(String[] args) {
		myclass myObj = new myclass();
		System.out.println(myObj.x);
	}

}
