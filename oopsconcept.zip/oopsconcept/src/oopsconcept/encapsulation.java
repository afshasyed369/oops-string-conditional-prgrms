public class Myclass {
	public static void main(String[] args) {
		Person myObj = new Person();
		myObj.setName("John"); //set the value of the name variable to "John"
		System.out.println(myObj.getName());
	}
}
