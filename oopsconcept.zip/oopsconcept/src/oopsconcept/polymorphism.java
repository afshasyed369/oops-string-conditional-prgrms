class Animal {
	public void animalSound() {
		System.out.println("The animal makes a sound");
	}
}
class Cat extends Animal {
	public void animalsound() {
		System.out.println("The cat says: meow meow");
	}
}

class Dog extends Animal {
	public void animalsound() {
		System.out.println("The dog says:bow bow");
	}
}

class MyMainClass {
	public static void main(String[] args) {
		Animal myAnimal = new Animal(); // Create a Animal object
		Animal myCat = new Cat(); // Create a Cat object
		Animal myDog = new Dog(); // Create a Dog object
		myAnimal.animalSound();
		myCat.animalSound();
		myDog.animalSound();
	}
}
