import java.util.Arrays;
class Main {
	public static void main(String[] args) {
		String vowels = "a::b::c::d:e";
		
		//splitting the string at "::"
		//storing the result in an array of strings
		string[] result = vowels.split("::");
		
		//converting array to string and printing it
		system.out.println("result =" + Arrays.toString(result));
	}
}