class Main {
	public static void main(String[] args) {
		String str1 = "C++ programming";
		
		//all  occurrences of "C++" is replaced with "Java"
		System.out.println(str1.replace("c++", "Java")); //Java programming
		
		//all occurrences of "aa' is replaced with "kk"
		System.out.println("aa bb aa zz".replace("aa", "kk")); // kk bb kk zz
		
		//substring not in the string
		System.out.println("Java".replace("c++", "C")); //Java
	}
}
