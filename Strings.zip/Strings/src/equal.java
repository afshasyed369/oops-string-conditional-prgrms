class Main {
	public static void main(String[] args) {
		String str1 = "Learn Python";
		String str2 = "Learn Java";
		//if str1 and str2 are equal, the result is true
		if(str1.equals(str2)) {
			System.out.println("str1 and str2 are equal");
		}
		else {
			System.out.println("str1 and str2 are not equal");
		}
	}
}