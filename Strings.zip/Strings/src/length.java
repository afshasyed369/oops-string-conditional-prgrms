class Main {
	public static void main(Strings[] args) {
		// create a string
		String s1 = "Hello! World";
		String s2 = "whatsup";
		System.out.println("String length is:"+s1.length());
		system.out.println("string length is:"+s2.length());
	}
}
